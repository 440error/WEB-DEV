% MATLAB Basic commands
A = [1, 2, 3; 4, 5, 6; 7, 8, 9]; % Example matrix
disp(A); % Display matrix
