% Read and display image
img = imread('example_image.jpg'); % Read image
imshow(img); % Display image
