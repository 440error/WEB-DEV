% Resize image
resized_img = imresize(img, [new_height, new_width]); % Specify new height and width
imshow(resized_img); % Display resized image
