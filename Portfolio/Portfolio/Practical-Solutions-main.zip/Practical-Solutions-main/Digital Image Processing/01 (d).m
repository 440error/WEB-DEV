% Convert color image to grayscale
gray_img = rgb2gray(img);
imshow(gray_img); % Display grayscale image
