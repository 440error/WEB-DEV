% Convert image to black & white
bw_img = im2bw(img, threshold); % Define a threshold (e.g., 0.5)
imshow(bw_img); % Display black & white image
