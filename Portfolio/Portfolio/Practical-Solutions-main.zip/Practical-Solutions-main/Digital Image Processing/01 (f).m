% Draw image profile
profile = improfile(img, x, y); % x and y are coordinates
plot(profile);
