% Separate color image into R, G, & B planes
R = img(:,:,1); % Red plane
G = img(:,:,2); % Green plane
B = img(:,:,3); % Blue plane
