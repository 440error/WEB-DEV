% Create color image using R, G, & B planes
color_img = cat(3, R, G, B); % Combine R, G, & B planes
imshow(color_img); % Display color image
