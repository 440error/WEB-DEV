% Flow control and LOOP
for i = 1:10
    disp(i); % Display iteration count
end
