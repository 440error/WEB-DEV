% Write 2-D data to an image file
imwrite(data, 'output_image.jpg'); % 'data' is the 2-D matrix to be saved
