ping 192.168.1.100
tracert 192.168.1.100
netstat -ano | findstr "TCP"