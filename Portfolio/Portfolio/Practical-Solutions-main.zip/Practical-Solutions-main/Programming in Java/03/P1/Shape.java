package P1;

public abstract class Shape {

    public abstract void get() throws java.io.IOException;

    public abstract double area() throws java.io.IOException;
}